const Colour_Box = document.getElementById(`Box`)

const Random_Button = document.getElementById(`Random_Button`)
const Auto_Checkbox = document.getElementById(`Auto_Box`)

const Red_Input = document.getElementById(`Red_Input`)
const Green_Input = document.getElementById(`Green_Input`)
const Blue_Input = document.getElementById(`Blue_Input`)
const Alpha_Input = document.getElementById(`Alpha_Input`)

function OnInterval() {
	if (Auto_Checkbox.checked) {
		Update()
	}
}

function Update() {
	let Background_Colour = (Red_Input.value*2.56)+`, `+(Green_Input.value*2.56)+`, `+(Blue_Input.value*2.56)+`, `+(Alpha_Input.value/100)
    Colour_Box.style.backgroundColor = `rgba(`+Background_Colour+`)`
}

Random_Button.addEventListener(`click`, function() {
	console.log("randomized clicked")
	Red_Input.value = Math.round(Math.random() * 100)
	Green_Input.value = Math.round(Math.random() * 100)
	Blue_Input.value = Math.round(Math.random() * 100)
	Update()
})

Auto_Checkbox.addEventListener(`change`, function() {
	if (Auto_Checkbox.checked) {
		Update()
	}
})

Update()

setInterval(OnInterval, 200)